import tkinter as     tk
from   tkinter import ttk
from   tkinter import filedialog
from   PIL     import Image, ImageTk, ImageFilter
import os, shutil
Custom = 'C'
System = 'S'

############################################################
# ------ ########### Secondary Classes ############ ------ #
############################################################

class ETip:
    def __init__(self, text, delay=500, x=None, y=None) -> None:
        self.text=text; self.delay=delay; self.x=x; self.y=y

    def Set(self, text, delay=500, x=None, y=None):
        self.text=text; self.delay=delay; self.x=x; self.y=y
    
    def Get(self, type=dict):
        if type == tuple:
            return (self.text, self.delay, self.x, self.y)
        elif type == list:
            return [self.text, self.delay, self.x, self.y]
        elif type == dict:
            return {'text': self.text, 'delay': self.delay, 'x': self.x, 'y': self.y}

class Place:
    def __init__(self, x, y, relwidth=None, relheight=None, relx=None, rely=None, width=None, height=None) -> None:
        self.x = x; self.y = y; self.relwidth = relwidth; self.relheight = relheight; self.relx = relx; self.rely = rely
        self.width = width; self.height = height
    
    def Set(self, x, y, relwidth=None, relheight=None, relx=None, rely=None, width=None, height=None):
        self.x = x; self.y = y; self.relwidth = relwidth; self.relheight = relheight; self.relx = relx; self.rely = rely
        self.width = width; self.height = height
    
    def Get(self, type=dict):
        if type == tuple:
            return (self.x, self.y, self.relwidth, self.relheight, self.relx, self.rely, self.width, self.height)
        elif type == list:
            return [self.x, self.y, self.relwidth, self.relheight, self.relx, self.rely, self.width, self.height]
        elif type == dict:
            return {'x': self.x, 'y': self.y, 'relwidth': self.relwidth, 'relheight': self.relheight, 'relx': self.relx, 'rely': self.rely, 
                    'width' : self.width, 'height' : self.height}

class EFont:
    def __init__(self, font, fontsize=10, fonttype='bold'):
        self.font = font; self.fontsize = fontsize; self.fonttype=fonttype

    def Set(self, font, fontsize='15', fonttype='bold'):
        self.font = font; self.fontsize = fontsize; self.fonttype=fonttype
    
    def Get(self, type=dict):
        if type == tuple:
            return (self.font, self.fontsize, self.fonttype)
        elif type == list:
            return [self.font, self.fontsize, self.fonttype]
        elif type == dict:
            return {'font': self.font, 'fontsize': self.fontsize, 'fonttype': self.fonttype}

class EPath:
    def __init__(self) -> None: pass
    def BackWord(Path:str):
        PathList = Path.split('\\')
        PathList[-1] = ''
        j = 0
        for i in range(len(PathList)):
            if i+j != PathList.index(PathList[-1]):
                j += 1
                PathList.insert(i+j, '\\')
        return ''.join(PathList)

    def RemoveContentsFolder(folder:str):
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))

Folder    = EPath.BackWord    (os.path.dirname(os.path.abspath(__file__)))
FolderETK = os   .path.dirname(os.path.abspath(__file__)                 )

############################################################
#  --------- ############ Funcs ############## ----------- #
############################################################

def Debug(code:str):
    code = code.replace('px', '')
    code = code.replace(" ", "")
    Values = code.split(',')
    bg = 'SystemButtonFace'; fg=None; bordercolor=None; borderthick=3; font='arial'; fontsive=10; fonttype= 'normal'
    activebg=None; activefg=None; compundimg='top'; menubg='SystemButtonFace'; menufg='SystemButtonFace'; 
    amenubg='SystemButtonFace'; amenufg='SystemButtonFace'; bd=0

    for i in range(len(Values)):
        AfterSplit = Values[i].split(':')
        if AfterSplit[0] == 'bg'          : bg=AfterSplit[1]
        if AfterSplit[0] == 'fg'          : fg=AfterSplit[1]
        if AfterSplit[0] == 'bd'          : bd=AfterSplit[1]
        if AfterSplit[0] == 'bordercolor' : bordercolor=AfterSplit[1]
        if AfterSplit[0] == 'borderthick' : borderthick=int(AfterSplit[1])
        if AfterSplit[0] == 'font'        : font=AfterSplit[1]
        if AfterSplit[0] == 'fontsize'    : fontsive=int(AfterSplit[1])
        if AfterSplit[0] == 'fonttype'    : fonttype=AfterSplit[1]
        if AfterSplit[0] == 'activebg'    : activebg=AfterSplit[1]
        if AfterSplit[0] == 'activefg'    : activefg=AfterSplit[1]
        if AfterSplit[0] == 'compundimg'  : compundimg=AfterSplit[1]
        if AfterSplit[0] == 'MenuBG'      : menubg=AfterSplit[1]
        if AfterSplit[0] == 'MenuFG'      : menufg=AfterSplit[1]
        if AfterSplit[0] == 'MenuActiveBg': amenubg=AfterSplit[1]
        if AfterSplit[0] == 'MenuActiveFg': amenufg=AfterSplit[1]
    
    FinishValue = {'bg':bg, 'fg':fg,'bd':bd, 'bordercolor':bordercolor, 'borderthick':borderthick, 'font':font, 
            'FontSive':fontsive, 'FontType':fonttype, 'activebg':activebg, 'activefg':activefg, 'compundimg':compundimg,
            'MenuBG' : menubg, 'MenuFG' : menufg, 'MenuActiveBg' : amenubg, 'MenuActiveFg' : amenufg}
    return FinishValue

def DebugImg(code:str):
    filter_types = 'BLUR CONTOUR DETAIL SHARPEN SMOOTH'.split(' ')
    code = code.replace('px', '')
    code = code.replace(" ", "")
    Values = code.split(',')
    filer=None; x=None; y=None; 
    for i in range(len(Values)):
        AfterSplit = Values[i].split(':')
        if AfterSplit[0] == 'filter' : 
            for i in range(len(filter_types)):
                if AfterSplit[1] == filter_types[i]:
                    filer=AfterSplit[1]
        if AfterSplit[0] == 'X'      : x=AfterSplit[1]
        if AfterSplit[0] == 'Y'      : y=AfterSplit[1]

    FinishValue={'filter':filer, 'X':x, 'Y':y}
    return FinishValue

def DebugSystem(code:str):
    code = code.replace('px', '')
    code = code.replace(" ", "")
    Values = code.split(',')
    TP = 'PLACE'; rx=None; ry=None; rw=None; rh=None; x1=None; y1=None; w=None; h=None
    ipadx = None; ipady=None; pady=None; padx=None; fill=None; expand=False

    for i in range(len(Values)):
        AfterSplit = Values[i].split(':')
        if AfterSplit[0] == 'Type'      : TP=AfterSplit[1]
        if AfterSplit[0] == 'relx'      : rx=float(AfterSplit[1])
        if AfterSplit[0] == 'rely'      : ry=float(AfterSplit[1])
        if AfterSplit[0] == 'relwidth'  : rw=float(AfterSplit[1])
        if AfterSplit[0] == 'relheight' : rh=float(AfterSplit[1])
        if AfterSplit[0] == 'X'         : x1=int  (AfterSplit[1])
        if AfterSplit[0] == 'Y'         : y1=int  (AfterSplit[1])
        if AfterSplit[0] == 'width'     : w =int  (AfterSplit[1])
        if AfterSplit[0] == 'height'    : h =int  (AfterSplit[1])

        if AfterSplit[0] == 'ipadx'  : ipadx  = int(AfterSplit[1])
        if AfterSplit[0] == 'ipady'  : ipady  = int(AfterSplit[1])
        if AfterSplit[0] == 'padx'   : padx   = int(AfterSplit[1])
        if AfterSplit[0] == 'pady'   : pady   = int(AfterSplit[1])
        if AfterSplit[0] == 'fill'   : fill   = AfterSplit[1]
        if AfterSplit[0] == 'expand' : expand = int(AfterSplit[1])
        if AfterSplit[0] == 'width'     : w =int  (AfterSplit[1])
        if AfterSplit[0] == 'height'    : h =int  (AfterSplit[1])
    
    FinishValue = {'Type':TP, 'X':x1, 'Y':y1, 'rx':rx, 'ry':ry, 'rw':rw, 'rh':rh,
            'w':w, 'h':h, 'ipadx':ipadx, 'ipady':ipady, 'pady':pady,
            'padx' : padx, 'fill' : fill, 'expand' : expand}
    return FinishValue

def DebugAny(code:str):
    code = code.replace('px', '')
    code = code.replace(" ", "")
    Values = code.split(',')
    Finish = {}

    for i in range(len(Values)):
        try:
            AfterSplit = Values[i].split(':')
            Finish[AfterSplit[0]]=AfterSplit[1]
        except:
            print('WARNING: There is an error in convertAny func')
    
    return Finish

############################################################
#     ------ ############ Widgets ############# ---------- #
############################################################

class EButton:
    def __init__(self, master, text='Button', Style=Custom, StyleMainCode='bg : #242424, fg : white, bordercolor : grey, \
         borderthick : 3px, activebg : orange, activefg : black, compundimg : top, bd:0', StyleCode='',
         command=None, img=None, PlaceMent=Place(10, 10) ,ToolTip=ETip(text='a button', delay=500,x=25, y=20), 
         ToolTipSwitch=True, font=EFont('arial')):
        
        ## Vars ##
        self.ToolTip = ToolTip; self.ToolTipSwitch=ToolTipSwitch
        self.m = master; self.text=text
        if StyleMainCode != None and StyleMainCode != '': self.sty = Debug(StyleMainCode)
        else: self.sty = Debug('bg:#242424,fg:white,bordercolor:grey,borderthick:3px,activebg:orange,activefg:black,compundimg:top,bd:0')
        if StyleCode != None and StyleCode != '': self.style = DebugAny(StyleCode)
        self.mag = PlaceMent; self.font = font

        ## Style ##
        if Style == Custom:
            try:
                for key, value in self.style.items():
                    try:
                        self.sty.update({key:value})
                    except:
                        raise TypeError('Please type options correctly!')
            except: pass

            if self.mag.width != None and self.mag.height != None:
                self.border = tk.Frame(master, bg=self.sty['bordercolor'], bd=self.sty['bd'], width=self.mag.width+self.sty['borderthick']*2, 
                                       height=self.mag.height+self.sty['borderthick']*2)
                
            else:
                self.border = tk.Frame(master, bg=self.sty['bordercolor'], bd=self.sty['bd'], width=self.sty['borderthick']*2, 
                                       height=self.sty['borderthick']*2)


            self.wid = tk.Button(master, text=text, command=command, bd=self.sty['bd'], bg=self.sty['bg'], fg=self.sty['fg'],
                                activebackground=self.sty['activebg'], activeforeground=self.sty['activefg'], 
                                font=(self.font.font, self.font.fontsize, self.font.fonttype))

        elif Style == System:

            self.s = ttk.Style()
            self.s.configure('B.TButton',background=self.sty['bg'],foreground=self.sty['fg'],font=(self.font.font, self.font.fontsize)) # , sty['FontType']
            self.wid = ttk.Button(master, style='B.TButton', text=text, command=command)
            
        ## Image ##
        if img != None:
                self.img = img
                self.wid.configure(image=self.img.img)
                self.wid.image = self.img
        
        ## Place ##
        self.wid.place(x=self.mag.x, y=self.mag.y, relx=self.mag.relx, rely=self.mag.rely, width=self.mag.width, 
                       height=self.mag.height, relwidth=self.mag.relwidth, relheight=self.mag.relheight)
        master.update()

        if Style != System:

            if self.mag.width == None and self.mag.height == None:
                self.border.configure(width=self.wid.winfo_width()+int(self.sty['borderthick'])*2, 
                                    height=self.wid.winfo_height()+int(self.sty['borderthick'])*2)

            self.border.place(x=int(self.mag.x-int(self.sty['borderthick'])), y=int(self.mag.y-int(self.sty['borderthick'])), relx=self.mag.relx, 
                                rely=self.mag.rely, relwidth=self.mag.relwidth, relheight=self.mag.relheight)
        

        ## ToolTip ##
        if ToolTipSwitch == True:

            if self.wid['state'] == 'disabled':
                self.Tip = EToolTip(self.wid, self.ToolTip.text + ' (Disabled)', self.ToolTip.delay, 
                                          XPluseValue=self.ToolTip.x, YPluseValue=self.ToolTip.y)
            
            else:
                self.Tip = EToolTip(self.wid, self.ToolTip.text, self.ToolTip.delay, 
                                          XPluseValue=self.ToolTip.x, YPluseValue=self.ToolTip.y)

    def UpdateStatus(self):
        if self.ToolTipSwitch == True:

            if self.wid['state'] == 'disabled':
                self.Tip = EToolTip(self.wid, self.ToolTip.text + ' (Disabled)', self.ToolTip.delay, 
                                          XPluseValue=self.ToolTip.x, YPluseValue=self.ToolTip.y)
            
            else:
                self.Tip = EToolTip(self.wid, self.ToolTip.text, self.ToolTip.delay, 
                                          XPluseValue=self.ToolTip.x, YPluseValue=self.ToolTip.y)

    def bind(self, event, func): self.wid.bind(event, func)

class EStaticText:
    def __init__(self, master, text='StaticText', StyleMainCode='bg : SystemButtonFace, fg : black, \
                compundimg : top, bd:0', StyleCode='',img=None, PlaceMent=Place(10, 10),
                ToolTip=ETip(text='a text', delay=500,x=25, y=20),ToolTipSwitch=True, 
                font=EFont('arial')): 

        ## Vars ##
        if StyleMainCode != None and StyleMainCode != '': self.sty = Debug(StyleMainCode)
        else: self.sty = Debug('bg:#242424,fg:white,bordercolor:grey,borderthick:3px,activebg:orange,activefg:black,compundimg:top,bd:0')
        if StyleCode != None and StyleCode != '': self.style = DebugAny(StyleCode); self.mag = PlaceMent; self.m = master
        self.font = font; self.text = text; self.ToolTip = ToolTip; self.ToolTipSwitch = ToolTipSwitch
        try:
            for key, value in self.style.items():
                try:
                    self.sty.update({key:value})
                except:
                    raise TypeError('Please type options correctly!')
        except: pass

        self.wid = tk.Label(master, text=text, bg=self.sty['bg'], fg=self.sty['fg'], 
                            font=(font.font, font.fontsize, font.fonttype), 
                            compound=self.sty['compundimg'])
        
        ## Image ##
        if img != None:
                self.img = img
                self.wid.configure(image=self.img.img)
                self.wid.image = self.img
        

        ## Place ##
        self.wid.place(x=PlaceMent.x, y=PlaceMent.y, relx=PlaceMent.relx, rely=PlaceMent.rely, 
                       width=PlaceMent.width, height=PlaceMent.height)


        ## ToolTip ##
        if ToolTipSwitch == True:

            if self.wid['state'] == 'disabled':
                self.Tip = EToolTip(self.wid, self.ToolTip.text + ' (Disabled)', self.ToolTip.delay, 
                                          XPluseValue=self.ToolTip.x, YPluseValue=self.ToolTip.y)
            
            else:
                self.Tip = EToolTip(self.wid, self.ToolTip.text, self.ToolTip.delay, 
                                          XPluseValue=self.ToolTip.x, YPluseValue=self.ToolTip.y)

class EMenu:
    def __init__(self, master=None, StyleMainCode='bg : #242424, fg : white, activebg : orange, activefg : black', 
                StyleCode='', tearoff=0):
        
        if StyleMainCode != None and StyleMainCode != '': self.sty = Debug(StyleMainCode)
        else: self.sty = Debug('bg:#242424, fg:white, activebg:orange, activefg:black')
        if StyleCode != None and StyleCode != '': self.style = DebugAny(StyleCode)

        if isinstance(master, EMenu):
            self.wid = tk.Menu(master.wid, tearoff=tearoff, bg=self.sty['bg'], fg=self.sty['fg'], 
                               activebackground=self.sty['activebg'],
                               activeforeground=self.sty['activefg'])
        else:
            self.wid = tk.Menu(master, tearoff=tearoff, bg=self.sty['bg'], fg=self.sty['fg'], 
                               activebackground=self.sty['activebg'],
                               activeforeground=self.sty['activefg'])
        
    def SetState(self, State='normal'): 
        self.wid.config(state=State)

    def AddCommand(self, text='A Menu', img=None, compund='left', command=None, ImgStyle=None, menu=None):
        if img == None:
            self.wid.add_command(label=text, image=img, compound=compund, command=command)
        if isinstance(img, EImage):
            self.img = img
            self.wid.add_command(label=text, image=self.img, compound=compund, command=command, menu=menu)
            self.wid.image = self.img
    
    def AddCascade(self, text=None, menu=None):
        if isinstance(menu, EMenu):
            self.wid.add_cascade(label=text, menu=menu.wid)
        else:
            self.wid.add_cascade(label=text, menu=menu)
    
    def AddSeprator(self):
        self.wid.add_separator()

class EOptionSelector:
    def __init__(self, master, Style=Custom, StyleMainCode='bg : #444444, fg : white, MenuBG : #303030, MenuFG : white, activebg : orange,\
                MenuActiveBg : orange, MenuActiveFg : black', StyleCode='',
                var=None, Options=['1', '2', '3'], DefaultValue=0,
                PlaceMent=Place(10,10)):

        ## Vars ##
        self.mag = PlaceMent
        if StyleMainCode != None and StyleMainCode != '': self.sty = Debug(StyleMainCode)
        else: self.sty = Debug('bg : #444444, fg : white, MenuBG : #303030, MenuFG : white, activebg : orange,\
                                    MenuActiveBg : orange, MenuActiveFg : black')
        if StyleCode != None and StyleCode != '': self.style = DebugAny(StyleCode)
        if var == None: self.var = tk.StringVar()
        else: self.var = var
        self.var.set(DefaultValue); self.Options = Options
        down =b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x0e\x00\x00\x00\x07\x08\x06\x00\x00\x008G|\x19\x00\x00\x00\tpHYs\x00\x00\x10\x9b\x00\x00\x10\x9b\x01t\x89\x9cK\x00\x00\x00\x19tEXtSoftware\x00www.inkscape.org\x9b\xee<\x1a\x00\x00\x00OIDAT\x18\x95\x95\xce\xb1\x0e@P\x0cF\xe1\xefzI\x8fc$\x12\x111\x19\xec\x9e\x12\xcb\x95 A\x9d\xa4K\xff\x9e\xb6\t\x13J\xffX \xa1\xc7\x16\xac\x19\xc5\xb1!*\x8fy\xf6BB\xf7"\r_\xff77a\xcd\xbd\x10\xedI\xaa\xa3\xd2\xf9r\xf5\x14\xee^N&\x14\xab\xef\xa9\'\x00\x00\x00\x00IEND\xaeB`\x82'
        self.imgDown = tk.PhotoImage(data=down)
        up = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x0e\x00\x00\x00\x07\x08\x06\x00\x00\x008G|\x19\x00\x00\x00\tpHYs\x00\x00\x10\x9b\x00\x00\x10\x9b\x01t\x89\x9cK\x00\x00\x00\x19tEXtSoftware\x00www.inkscape.org\x9b\xee<\x1a\x00\x00\x00\\IDAT\x18\x95\x8d\xd0A\n\x830\x14\x06\xe1/z,\x0f\xd2#\x19\\\xb4\x08Ep\xe1\xbe\xd7\xe8\xc5\xd2n\x12\x11%\x92\x81\xd9<\xfe\xd9\xbc^\x9d\x88\x01\xdf\x9b\xcd\x85\t?$\x8c\xadQ\xccQ1\xe5[\x95\x80\xe7)::\xd7\xa2\xd7MT|\xe7\xed\x1e-\rQqC\x17\xb0\xe2\xd1\xfa\x80\xcc\xe7\x0fO\xbe&\x9dv\xae\xef\x97\x00\x00\x00\x00IEND\xaeB`\x82'
        self.imgUp = tk.PhotoImage(data=up)

        ## Style ##
        if Style == Custom:
            self.wid = tk.OptionMenu(master, self.var, *self.Options)

            self.wid.config(bg=self.sty['bg'], bd=self.sty['bd'], fg=self.sty['fg'], indicatoron=0, compound=tk.RIGHT,
                            image=self.imgDown, activebackground=self.sty['activebg'])

            self.wid.image1 = self.imgDown; self.wid.image2 = self.imgUp

            self.wid['menu'].config(bg=self.sty['MenuBG'], activebackground=self.sty['MenuActiveBg'], fg=self.sty['MenuFG'], 
                                    activeforeground=self.sty['MenuActiveFg'])

            menu = self.wid['menu']
            menu.configure(postcommand=lambda: self.wid.configure(image=self.imgUp))
            menu.bind('<Unmap>', lambda ev: self.wid.configure(image=self.imgDown))
            self.wid.place(x=self.mag.x, y=self.mag.y, relx=self.mag.relx, rely=self.mag.rely, width=self.mag.width, 
                       height=self.mag.height, relwidth=self.mag.relwidth, relheight=self.mag.relheight)
        else:
            raise TypeError('ETK 0.1 does not support EOptionSelector with System Style.')

class EImage:
    def __init__(self, img:str, ImgStyle=None):
        if os.path.exists(img):
            self.imgpath = img
            load = Image.open(img)
        else:
            self.imgpath = os.path.join(Folder, img)
            load = Image.open(self.imgpath)
        if ImgStyle != None:
                    ImageStyle = DebugImg(ImgStyle)
                    gg = self.imgpath.split('\\')
                    if ImageStyle['filter'] == 'BLUR'   : load = load.filter(ImageFilter.BLUR   ); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                    if ImageStyle['filter'] == 'CONTOUR': load = load.filter(ImageFilter.CONTOUR); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                    if ImageStyle['filter'] == 'DETAIL' : load = load.filter(ImageFilter.DETAIL ); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                    if ImageStyle['filter'] == 'SHARPEN': load = load.filter(ImageFilter.SHARPEN); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                    if ImageStyle['filter'] == 'SMOOTH' : load = load.filter(ImageFilter.SMOOTH ); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                    else: pass
                    self.load = Image.open(self.imgpath)
                    x1 = ImageStyle['X']; y1 = ImageStyle['Y']
                    if x1 != None and y1 != None:
                        size = (int(x1), int(y1))
                        self.load = self.load.resize(size, Image.ANTIALIAS)
        self.img = ImageTk.PhotoImage(self.load)

class EToolTip(object):
    def __init__(self, widget, text='A ToolTip', delay=500, XPluseValue=25, YPluseValue=20):
        self.waittime = delay     #miliseconds
        self.wraplength = 180     #pixels
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)
        self.widget.bind("<ButtonPress>", self.leave)
        self.id = None
        self.tw = None
        self.XPluseValue = XPluseValue
        self.YPluseValue = YPluseValue

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(self.waittime, self.showtip)

    def unschedule(self):
        id = self.id
        self.id = None
        if id:
            self.widget.after_cancel(id)

    def showtip(self, event=None):
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + self.XPluseValue
        y += self.widget.winfo_rooty() + self.YPluseValue
        # creates a toplevel window
        self.tw = tk.Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = tk.Label(self.tw, text=self.text, justify='left',
                       background="#ffffff", relief='solid', borderwidth=1,
                       wraplength = self.wraplength)
        label.pack(ipadx=1)

    def hidetip(self):
        tw = self.tw
        self.tw= None
        if tw:
            tw.destroy()

class EStringInput:
    def __init__(self, master, StyleMainCode='bg:#303030, fg:green, borderthick:3px, bordercolor:#404040, \
                bd:0, activeborder-color:grey', StyleCode='', Font=EFont('arial'),
                PlaceMent=Place(10, 10), Justify='left', ReadOnly=False, Var=None):
        
        if Var == None : self.var = tk.StringVar()
        else           : self.var = Var
        self.mag = PlaceMent; self.master = master;self.Focus = False; 
        if StyleMainCode != None and StyleMainCode != '': self.sty = DebugAny(StyleMainCode)
        else: self.sty = DebugAny('bg:#303030, fg:green, borderthick:3px, bordercolor:#404040, \
                                bd:0, activeborder-color:grey')
        if StyleCode != None and StyleCode != '': self.style = DebugAny(StyleCode)
        print(self.sty)
        self.ActiveBorderColor = self.sty['activeborder-color']
        

        self.wid = tk.Entry(master, bg=self.sty['bg'], fg=self.sty['fg'], highlightthickness=self.sty['borderthick'], 
                            highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'],
                            font=(Font.font, Font.fontsize, Font.fonttype), justify=Justify, 
                            textvariable=self.var, bd=self.sty['bd'])

        if ReadOnly == True : self.wid.config(state='readonly')
        else                : self.wid.config(state='normal'  )

        self.wid.place(x=self.mag.x, y=self.mag.y, relheight=self.mag.relheight, relwidth=self.mag.relwidth, 
                       relx=self.mag.relx, rely=self.mag.rely, width=self.mag.width, height=self.mag.height)
            
        self.wid.bind('<Enter>'   , self.MouseEnter)
        self.wid.bind('<Leave>'   , self.MouseLeave)

    def SetState(self, state:str): 
        self.wid.config(state=state)
    def WhenValueChanged(self, Function): 
        self.var.trace('w', Function)
    def Get(self): 
        return self.var.get()
    def MouseEnter(self, e): 
        self.wid.bind('<Button-1>', self.ClickAndOver)
        self.wid.config(highlightbackground=self.ActiveBorderColor, highlightcolor=self.ActiveBorderColor, highlightthickness=2)
    def ClickAndOver(self, e):
        self.Focus = True
        self.wid.unbind('<Enter>')
        self.wid.unbind('<Leave>')
        self.wid.config(highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'], highlightthickness=self.sty['borderthick'])
    def ClickAndLeave(self, e):
        if isinstance(e.widget,tk.Tk): #check if event widget is Tk root window
            self.Focus = False
            print("Jere")
            self.wid.bind('<Enter>'   , self.MouseEnter)
            self.wid.bind('<Leave>'   , self.MouseLeave)
            self.wid.config(highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'], highlightthickness=self.sty['borderthick'])
    def MouseLeave(self, e): 
        parent_name = self.wid.winfo_parent()
        parent = self.wid._nametowidget(parent_name)
        parent.bind('<Button-1>', self.ClickAndLeave)
        self.wid.config(highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'], highlightthickness=self.sty['borderthick'])
    def SetText(self, text:str): 
        self.var.set(text)
    def AppendText(self, index, text:int):
        self.wid.insert(index, str(text))
    def RemoveChar(self, index):
        self.wid.delete(index)
    def RemoveText(self, First, Last):
        self.wid.delete(First, Last)
    def RemoveLastChar(self):
        self.wid.delete(len(self.var.get())-1, 'end')
    def RemoveText(self):
        self.var.set('')

class EIntegerInput:
    def __init__(self, master, StyleMainCode='bg:#303030, fg:green, borderthick:3px, bordercolor:#404040, \
                bd:0, activeborder-color:grey', StyleCode='', Font=EFont('arial'),
                PlaceMent=Place(10, 10), Justify='left', ReadOnly=False, Var=None):
        if Var == None : self.var = tk.StringVar()
        else           : self.var = Var
        self.mag = PlaceMent; self.master = master;self.Focus = False; 
        if StyleMainCode != None and StyleMainCode != '': self.sty = DebugAny(StyleMainCode)
        else: self.sty = DebugAny('bg:#303030, fg:green, borderthick:3px, bordercolor:#404040, \
                                bd:0, activeborder-color:grey')
        if StyleCode != None and StyleCode != '': self.style = DebugAny(StyleCode)
        print(self.sty)
        self.ActiveBorderColor = self.sty['activeborder-color']
        

        self.wid = tk.Entry(master, bg=self.sty['bg'], fg=self.sty['fg'], highlightthickness=self.sty['borderthick'], 
                            highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'],
                            font=(Font.font, Font.fontsize, Font.fonttype), justify=Justify, 
                            textvariable=self.var, bd=self.sty['bd'])

        if ReadOnly == True : self.wid.config(state='readonly')
        else                : self.wid.config(state='normal'  )

        self.wid.place(x=self.mag.x, y=self.mag.y, relheight=self.mag.relheight, relwidth=self.mag.relwidth, 
                       relx=self.mag.relx, rely=self.mag.rely, width=self.mag.width, height=self.mag.height)
        self.wid.bind('<Enter>'   , self.MouseEnter)
        self.wid.bind('<Leave>'   , self.MouseLeave)
        self.var.trace('w', self.Changed)

    def SetState(self, state:str): 
        self.wid.config(state=state)
    def WhenValueChanged(self, Function): 
        self.var.trace('w', Function)
    def Get(self): 
        return self.var.get()
    def MouseEnter(self, e): 
        self.wid.bind('<Button-1>', self.ClickAndOver)
        self.wid.config(highlightbackground=self.ActiveBorderColor, highlightcolor=self.ActiveBorderColor, highlightthickness=2)
    def ClickAndOver(self, e):
        self.Focus = True
        self.wid.unbind('<Enter>')
        self.wid.unbind('<Leave>')
        self.wid.config(highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'], highlightthickness=self.sty['borderthick'])
    def ClickAndLeave(self, e):
        if isinstance(e.widget,tk.Tk): #check if event widget is Tk root window
            self.Focus = False
            print("Jere")
            self.wid.bind('<Enter>'   , self.MouseEnter)
            self.wid.bind('<Leave>'   , self.MouseLeave)
            self.wid.config(highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'], highlightthickness=self.sty['borderthick'])
    def MouseLeave(self, e): 
        parent_name = self.wid.winfo_parent()
        parent = self.wid._nametowidget(parent_name)
        parent.bind('<Button-1>', self.ClickAndLeave)
        self.wid.config(highlightbackground=self.sty['bordercolor'], highlightcolor=self.sty['bordercolor'], highlightthickness=self.sty['borderthick'])
    def SetText(self, text:str): 
        self.var.set(text)
    def __Enter(self, e):
        self.SetText(self.__gg)
    def Changed(self, gg, hh, ll):
        if ' ' in self.var.get():
            print('\a'); self.wid.delete(len(self.var.get())-1, 'end')
        if '+' not in self.var.get() and '-' not in self.var.get() and '*' not in self.var.get() and '/' not in self.var.get():
            try: int(self.var.get())
            except ValueError: print('\a'); self.wid.delete(len(self.var.get())-1, 'end'); print('G')
        if '+' in self.var.get() or '-' in self.var.get() or '*' in self.var.get() or '/' in self.var.get():
            try: 
                self.__gg = int(eval(self.var.get())); self.wid.bind('<Return>', self.__Enter)
            except: 
                try : x = eval('1'+self.var.get()[-1]+'1')
                except : print('\a'); self.wid.delete(len(self.var.get())-1, 'end'); print('B')
    def AppendText(self, index, text:int):
        self.wid.insert(index, str(text))
    def RemoveChar(self, index):
        self.wid.delete(index)
    def RemoveText(self, First, Last):
        self.wid.delete(First, Last)
    def RemoveLastChar(self):
        self.wid.delete(len(self.var.get())-1, 'end')
    def RemoveText(self):
        self.var.set('')

class EPathInput:
    def __init__(self, master, Style='bg:#303030, fg:green, borderthick:2px, bordercolor:#404040', Sys='Type:PLACE, X:10, Y:50',
                Justify='left', Var=None, bd=None, WarnColor='yellow', ErrorColor='red', CoolColor='green', Type='DIR', 
                OpenWinTitle='insert the path: ', Ext=(('Images Files', '*.png *.jpg *.gif *.jpeg *.bmp'), ('All Files', '*.*')), BBG="#242424"):
        self.WarnColor = WarnColor; self.ErrorColor = ErrorColor; self.CoolColor = CoolColor; self.Type = Type
        self.OpenWinTitle = OpenWinTitle; self.Ext = Ext; self.m = master; self.BBG = BBG
        if Var == None : self.var = tk.StringVar()
        else           : self.var = Var
        self.S  = Debug(Style)
        self.SY = DebugSystem(Sys)
        self.wid = tk.Entry(master, bg=self.S['bg'], fg=self.S['fg'], highlightthickness=self.S['borderthick'], 
                            highlightbackground=self.WarnColor, highlightcolor=self.WarnColor,
                            font=(self.S['font'], self.S['FontSive'], self.S['FontType']), justify=Justify, textvariable=self.var, bd=bd)

        if self.SY['Type'] == 'PLACE':
            self.wid.place(x=self.SY['X'], y=self.SY['Y'], relheight=self.SY['rh'], relwidth=self.SY['rw'], 
                            relx=self.SY['rx'], rely=self.SY['ry'], width=self.SY['w'], height=self.SY['h'])
        elif self.SY['Type'] == 'PACK':
            self.wid.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                            fill=self.SY['fill'], expand=self.SY['expand'], width=self.SY['w'], height=self.SY['h'])
        master.update()
        
        self.BBtn = EButton(master, '', img=EImage(os.path.join(FolderETK, 'Data\\FOLDER.png'), 
                            f'Y:{self.wid.winfo_height()-3}, X:{self.wid.winfo_height()-3}'), 
                            StyleCode=f'bg:{BBG}, borderthick:1px, bordercolor:grey', 
                            PlaceMent=Place(x=self.SY['X']+self.wid.winfo_width()+1, y=self.SY['Y']), command=self.Open, 
                            ToolTip=ETip('Browse...'))
        master.after(500, self.Update)
        self.var.trace('w', self.Check)
        self.Tip = EToolTip(self.wid, 'Insert a path.')
    def Open(self):
        if self.Type == 'DIR':
            DIR = filedialog.askdirectory(title=self.OpenWinTitle)
            self.var.set(DIR)
            if os.path.isdir(self.var.get()):
                try:
                    self.Tip.tw.destroy()
                except: pass
                self.wid.config(highlightcolor=self.CoolColor, highlightbackground=self.CoolColor, fg=self.CoolColor)
                self.Tip = EToolTip(self.wid, 'This path is valid.')
            else:
                try:
                    self.Tip.tw.destroy()
                except: pass
                self.wid.config(highlightcolor=self.ErrorColor, highlightbackground=self.ErrorColor, fg=self.ErrorColor)
                self.Tip = EToolTip(self.wid, "Can't use this Path !")
        elif self.Type == 'FIL':
            FIL = filedialog.askopenfilename(title=self.OpenWinTitle, filetypes=self.Ext)
            self.var.set(FIL)
            if os.path.exists(self.var.get()):
                try:
                    self.Tip.tw.destroy()
                except: pass
                self.wid.config(highlightcolor=self.CoolColor, highlightbackground=self.CoolColor, fg=self.CoolColor)
                self.Tip = EToolTip(self.wid, 'This path is valid.')
            else:
                try:
                    self.Tip.tw.destroy()
                except: pass
                self.wid.config(highlightcolor=self.ErrorColor, highlightbackground=self.ErrorColor, fg=self.ErrorColor)
                self.Tip = EToolTip(self.wid, "Can't use this Path !")
    def Check(self, e, g, h):
        if self.var.get() != '':
            if os.path.isdir(self.var.get()) or os.path.exists(self.var.get()):
                try:
                    self.Tip.tw.destroy()
                except: pass
                self.Tip = EToolTip(self.wid, 'This path is valid.')
                self.wid.config(highlightcolor=self.CoolColor, highlightbackground=self.CoolColor, fg=self.CoolColor)
            else:
                try:
                    self.Tip.tw.destroy()
                except: pass
                self.wid.config(highlightcolor=self.ErrorColor, highlightbackground=self.ErrorColor, fg=self.ErrorColor)
                self.Tip = EToolTip(self.wid, "Can't use this Path !")
        else:
            try:
                self.Tip.tw.destroy()
            except: pass
            self.wid.config(highlightcolor=self.WarnColor, highlightbackground=self.WarnColor, fg=self.WarnColor)
            self.Tip = EToolTip(self.wid, "Insert a path.")
    def Get(self):
        return self.var.get()
    def Update(self):
        self.BBtn.wid.destroy()
        self.BBtn = EButton(self.m, '', img=EImage(os.path.join(FolderETK, 'Data\\FOLDER.png'), 
                            f'Y:{self.wid.winfo_height()-3}, X:{self.wid.winfo_height()-3}'), 
                            StyleCode=f'bg:{self.BBG}, borderthick:1px, bordercolor:grey', 
                            PlaceMent=Place(x=self.SY['X']+self.wid.winfo_width()+1, y=self.SY['Y']), command=self.Open, 
                            ToolTip=ETip('Browse...'))
        self.wid.update_idletasks()
        #self.m.after(1000, self.Update)

class EShape:
    def __init__(self, master, Color='red', Size=(50, 50), Sys='Type:PLACE, X:10, Y:10', BorderColor='grey', BorderThick=3, bd=0,
                img=None, ImgStyle=None):
        self.BorderThick = BorderThick; self.master = master; self.Size = Size
        self.SY = DebugSystem(Sys)
        self.border = tk.Frame(master, bg=BorderColor, bd=bd, width=BorderThick*2, height=BorderThick*2)
        self.wid = tk.Frame(master, bg=Color)
        if self.SY['Type'] == 'PLACE':
            self.wid.place(x=self.SY['X'], y=self.SY['Y'], relheight=self.SY['rh'], relwidth=self.SY['rw'], 
                            relx=self.SY['rx'], rely=self.SY['ry'], width=Size[0], height=Size[1])
            master.update()
            if BorderThick != 0:
                if self.SY['rh'] != 0 and self.SY['rw'] == None:
                    self.border.configure(width=self.wid.winfo_width()+BorderThick*2)#, 
                                            #height=self.wid.winfo_height()+BorderThick*2)
                    self.border.place(x=int(self.SY['X']-BorderThick), y=int(self.SY['Y']-BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], height=self.wid.winfo_height()-(470+BorderThick))
                elif self.SY['rh'] != 0 and self.SY['rw'] == None:
                    self.border.configure(#width=self.wid.winfo_width()+BorderThick*2,
                                            height=self.wid.winfo_height()+BorderThick*2)
                    self.border.place(x=int(self.SY['X']-BorderThick), y=int(self.SY['Y']-BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], width=self.wid.winfo_width()-(470+BorderThick))
                elif self.SY['rh'] != 0 and self.SY['rw'] != None:
                    #self.border.configure(width=self.wid.winfo_width()+BorderThick*2,
                    #                        height=self.wid.winfo_height()+BorderThick*2)
                    self.border.place(x=int(self.SY['X']-BorderThick), y=int(self.SY['Y']-BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], width=self.wid.winfo_width()-(470+BorderThick),
                                        height=self.wid.winfo_height()-(470+BorderThick))
                else:
                    self.border.configure(width=self.wid.winfo_width()+BorderThick*2,
                                            height=self.wid.winfo_height()+BorderThick*2)
                    self.border.place(x=int(self.SY['X']-BorderThick), y=int(self.SY['Y']-BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'])
        elif self.SY['Type'] == 'PACK':
            self.wid.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                            fill=self.SY['fill'], expand=self.SY['expand'], width=Size[0], height=Size[1])
            master.update()
            if BorderThick != 0:
                self.border.configure(width=self.wid.winfo_width()+BorderThick*2, 
                                        height=self.wid.winfo_height()+BorderThick*2)
                self.border.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                                fill=self.SY['fill'], expand=self.SY['expand'])
        self.widimg = tk.Label(self.wid, text='', bg=Color)
        self.widimg.place(relx=0.5, rely=0.5, anchor='center')
        if img != None:
                if os.path.exists(img):
                    self.imgpath = img
                    load = Image.open(img)
                else:
                    self.imgpath = os.path.join(Folder, img)
                    load = Image.open(self.imgpath)
                if ImgStyle != None:
                        ImageStyle = DebugImg(ImgStyle)
                        gg = self.imgpath.split('\\')
                        if ImageStyle['filter'] == 'BLUR'   : load = load.filter(ImageFilter.BLUR   ); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                        if ImageStyle['filter'] == 'CONTOUR': load = load.filter(ImageFilter.CONTOUR); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                        if ImageStyle['filter'] == 'DETAIL' : load = load.filter(ImageFilter.DETAIL ); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                        if ImageStyle['filter'] == 'SHARPEN': load = load.filter(ImageFilter.SHARPEN); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                        if ImageStyle['filter'] == 'SMOOTH' : load = load.filter(ImageFilter.SMOOTH ); load.save(f'c:\\Windows\Temp\\{gg[-1]}'); self.imgpath = f'c:\\Windows\Temp\\{gg[-1]}'
                        else: pass
                        load = Image.open(self.imgpath)
                        x1 = ImageStyle['X']
                        y1 = ImageStyle['Y']
                        if x1 != None and y1 != None:
                            size = (int(x1), int(y1))
                            load = load.resize(size, Image.ANTIALIAS)
                self.img = ImageTk.PhotoImage(load)
                self.widimg.configure(image=self.img)
                self.widimg.image = self.img
    def Hide(self):
        self.wid.place_forget(); self.border.place_forget()
    def Show(self):
        if self.SY['Type'] == 'PLACE':
            self.wid.place(x=self.SY['X'], y=self.SY['Y'], relheight=self.SY['rh'], relwidth=self.SY['rw'], 
                            relx=self.SY['rx'], rely=self.SY['ry'], width=self.Size[0], height=self.Size[1])
            self.master.update()
            if self.BorderThick != 0:
                if self.SY['rh'] != 0 and self.SY['rw'] == None:
                    self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2)#, 
                                            #height=self.wid.winfo_height()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], height=self.wid.winfo_height()-(470+self.BorderThick))
                elif self.SY['rh'] != 0 and self.SY['rw'] == None:
                    self.border.configure(#width=self.wid.winfo_width()+self.BorderThick*2,
                                            height=self.wid.winfo_height()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], width=self.wid.winfo_width()-(470+self.BorderThick))
                elif self.SY['rh'] != 0 and self.SY['rw'] != None:
                    #self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2,
                    #                        height=self.wid.winfo_height()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], width=self.wid.winfo_width()-(470+self.BorderThick),
                                        height=self.wid.winfo_height()-(470+self.BorderThick))
                else:
                    self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2,
                                            height=self.wid.winfo_height()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'])
        elif self.SY['Type'] == 'PACK':
            self.wid.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                            fill=self.SY['fill'], expand=self.SY['expand'], width=self.Size[0], height=self.Size[1])
            self.master.update()
            if self.BorderThick != 0:
                self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2, 
                                        height=self.wid.winfo_height()+self.BorderThick*2)
                self.border.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                                fill=self.SY['fill'], expand=self.SY['expand'])
    def UpdateBorderStatement(self):
        if self.SY['Type'] == 'PLACE':
            self.master.update()
            if self.BorderThick != 0:
                if self.SY['rh'] != 0 and self.SY['rw'] == None:
                    self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], height=self.wid.winfo_height()-(470+self.BorderThick))
                elif self.SY['rh'] != 0 and self.SY['rw'] == None:
                    self.border.configure(height=self.wid.winfo_height()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], width=self.wid.winfo_width()-(470+self.BorderThick))
                elif self.SY['rh'] != 0 and self.SY['rw'] != None:
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'], width=self.wid.winfo_width()-(470+self.BorderThick),
                                        height=self.wid.winfo_height()-(470+self.BorderThick))
                else:
                    self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2,
                                            height=self.wid.winfo_height()+self.BorderThick*2)
                    self.border.place(x=int(self.SY['X']-self.BorderThick), y=int(self.SY['Y']-self.BorderThick), relx=self.SY['rx'], rely=self.SY['ry'], 
                                        relwidth=self.SY['rw'], relheight=self.SY['rh'])
        elif self.SY['Type'] == 'PACK':
            self.master.update()
            if self.BorderThick != 0:
                self.border.configure(width=self.wid.winfo_width()+self.BorderThick*2, 
                                        height=self.wid.winfo_height()+self.BorderThick*2)
                self.border.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                                fill=self.SY['fill'], expand=self.SY['expand'])

class EViewTree:
    def __init__(self, master, Sys='Type:PLACE, X:10, Y:0', w=125, h=200, Style='bg:#404040, fg:white, MenuBG:#404040', Theme='clam'):
        self.ST = Debug(Style)
        self.SY = DebugSystem(Sys)
        self.S = ttk.Style(); self.S.theme_use(Theme)
        self.S.configure("Treeview", background=self.ST['bg'], 
                fieldbackground=self.ST['MenuBG'], foreground=self.ST['fg'])
        self.wid = ttk.Treeview(master)
        if self.SY['Type'] == 'PLACE':
            self.wid.place(x=self.SY['X'], y=self.SY['Y'], relheight=self.SY['rh'], relwidth=self.SY['rw'], 
                            relx=self.SY['rx'], rely=self.SY['ry'], width=w/1.26, height=h/1.26)
        elif self.SY['Type'] == 'PACK':
            self.wid.pack(padx=self.SY['padx'], pady=self.SY['pady'], ipadx=self.SY['ipadx'], ipady=self.SY['ipady'], 
                            fill=self.SY['fill'], expand=self.SY['expand'], width=w/1.26, height=h/1.26)
